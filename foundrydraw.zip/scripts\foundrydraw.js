/**
 * FoundryDraw - Magic Circle Painter
 * A drawing canvas for painting magic circles in Foundry VTT v13.
 * v1.6.0 — SVG drawing engine: infinite resolution, crisp at every zoom level,
 *           exports as a true .svg file.  Raster canvas replaced by a live
 *           <svg> element; pan / zoom change the viewBox instead of blitting
 *           a world canvas.  History stores cloned SVG nodes (~KB each) instead
 *           of 16 MB ImageData snapshots.  Flood fill removed (raster-only op).
 */

const MODULE_ID = "foundrydraw";

// ─── World coordinate space ───────────────────────────────────────────────────
// All drawing coordinates are in a 2000×2000 world.  The display is a
// zoomable / pannable viewport (SVG viewBox) into that world.
const WORLD_SIZE  = 2000;
const MAX_HISTORY = 20;
const ZOOM_MIN    = 0.1;
const ZOOM_MAX    = 8.0;
const ZOOM_FACTOR = 1.15;
const SVG_NS      = "http://www.w3.org/2000/svg";
const PARCHMENT   = "#e8d5a3";   // background fill colour (also used by eraser)

/* ──────────────────────────────────────────────
   Settings
   ────────────────────────────────────────────── */

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, "gallery", {
    scope:   "client",   // each player keeps their own gallery in their browser
    config:  false,
    type:    Array,
    default: [],
  });
});

/* ──────────────────────────────────────────────
   Application
   ────────────────────────────────────────────── */

class FoundryDrawApp extends Application {
  constructor(options = {}) {
    super(options);

    this._history   = [];
    this._redoStack = [];
    this._drawing   = false;
    this._panning   = false;
    this._lastX     = 0;   // world coords of last stabilised brush position
    this._lastY     = 0;
    this._startX    = 0;   // world coords at pointer-down (for shapes)
    this._startY    = 0;
    this._panLastX  = 0;   // client coords for pan delta calculation
    this._panLastY  = 0;

    this._tool       = "brush";
    this._color      = "#030821";
    this._brushSize  = 4;
    this._smoothness = 10;  // 0 = off, 1-10 = increasing EMA stabilisation
    this._smoothX    = 0;   // stabilised draw position (world coords)
    this._smoothY    = 0;
    this._opacity    = 1.0;
    this._symmetry   = 1;
    this._keyHandler = null;

    // Viewport state (same model as the old canvas approach)
    this._zoom  = 1.0;
    this._viewX = 0;   // world-x at the top-left of the viewport
    this._viewY = 0;   // world-y at the top-left of the viewport

    // Insert-circle mode: true while waiting for the user to click a radius
    this._insertCircleMode = false;

    // Live-stroke state: one <path> per symmetry axis while the pointer is down
    this._activePaths = [];
    this._pathDataArr = [];
  }

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id:          "foundrydraw-app",
      title:       game.i18n.localize("FOUNDRYDRAW.WindowTitle"),
      template:    null,
      classes:     ["foundrydraw-app"],
      width:       820,
      height:      700,
      resizable:   true,
      minimizable: true,
    });
  }

  async _renderInner() {
    const i18n = (k) => game.i18n.localize(`FOUNDRYDRAW.${k}`);

    const html = `
<div class="foundrydraw-toolbar">

  <button class="fd-tool-btn active" data-tool="brush"  data-tooltip="${i18n("Tools.Brush")}">
    <i class="fas fa-paint-brush"></i>
  </button>
  <button class="fd-tool-btn" data-tool="eraser"        data-tooltip="${i18n("Tools.Eraser")}">
    <i class="fas fa-eraser"></i>
  </button>
  <button class="fd-tool-btn" data-tool="line"          data-tooltip="${i18n("Tools.Line")}">
    <i class="fas fa-minus"></i>
  </button>
  <button class="fd-tool-btn" data-tool="circle"        data-tooltip="${i18n("Tools.Circle")}">
    <i class="fas fa-circle-notch"></i>
  </button>
  <button class="fd-tool-btn" data-tool="rect"          data-tooltip="${i18n("Tools.Rectangle")}">
    <i class="fas fa-square"></i>
  </button>

  <div class="separator"></div>

  <div class="fd-color-btn" title="${i18n("Settings.Color")}">
    <input type="color" id="fd-color-picker" value="#030821">
  </div>

  <div class="separator"></div>

  <div class="fd-slider-group">
    <label>${i18n("Settings.BrushSize")}</label>
    <input type="range" id="fd-brush-size" min="1" max="20" value="${this._brushSize}">
    <span class="fd-val" id="fd-brush-size-val">${this._brushSize}</span>
  </div>

  <div class="fd-slider-group">
    <label>${i18n("Settings.Smoothness")}</label>
    <input type="range" id="fd-smooth" min="0" max="10" value="10">
    <span class="fd-val" id="fd-smooth-val">10</span>
  </div>

  <div class="separator"></div>

  <div class="fd-slider-group">
    <label>${i18n("Settings.Symmetry")}</label>
    <select class="fd-select" id="fd-symmetry">
      <option value="1"  selected>${i18n("Settings.SymmetryNone")}</option>
      <option value="2">${i18n("Settings.Symmetry2")}</option>
      <option value="4">${i18n("Settings.Symmetry4")}</option>
      <option value="6">${i18n("Settings.Symmetry6")}</option>
      <option value="8">${i18n("Settings.Symmetry8")}</option>
      <option value="12">${i18n("Settings.Symmetry12")}</option>
    </select>
  </div>

  <div class="separator"></div>

  <button class="fd-tool-btn" id="fd-undo"          data-tooltip="${i18n("Actions.Undo")}">
    <i class="fas fa-undo"></i>
  </button>
  <button class="fd-tool-btn" id="fd-redo"          data-tooltip="${i18n("Actions.Redo")}">
    <i class="fas fa-redo"></i>
  </button>
  <button class="fd-tool-btn" id="fd-insert-circle" data-tooltip="${i18n("Actions.InsertCircle")}">
    <i class="fas fa-circle-plus"></i>
  </button>
  <button class="fd-tool-btn" id="fd-center-view"   data-tooltip="${i18n("Actions.CenterView")}">
    <i class="fas fa-compress-arrows-alt"></i>
  </button>
  <button class="fd-tool-btn" id="fd-clear"         data-tooltip="${i18n("Actions.Clear")}">
    <i class="fas fa-trash"></i>
  </button>
  <button class="fd-tool-btn" id="fd-clipboard"     data-tooltip="${i18n("Actions.CopyClipboard")}">
    <i class="fas fa-clipboard"></i>
  </button>
  <button class="fd-tool-btn" id="fd-save-gallery"  data-tooltip="${i18n("Actions.SaveGallery")}">
    <i class="fas fa-floppy-disk"></i>
  </button>
  <button class="fd-tool-btn" id="fd-save"          data-tooltip="${i18n("Actions.Save")}">
    <i class="fas fa-download"></i>
  </button>

  ${game.user.isGM ? `
  <div class="separator"></div>
  <button class="fd-tool-btn" id="fd-show-players" data-tooltip="${i18n("Actions.ShowPlayers")}">
    <i class="fas fa-eye"></i>
  </button>` : ""}

</div>

<div class="foundrydraw-canvas-wrap" id="fd-canvas-wrap">
  <svg id="foundrydraw-svg" xmlns="${SVG_NS}"></svg>
  <div id="fd-center-marker" title="${i18n("Settings.SymmetryCenter")}"><span></span></div>
</div>

<div class="foundrydraw-status">
  <span class="fd-coords" id="fd-coords">x: 0  y: 0</span>
  <span id="fd-zoom-info">100%</span>
  <span id="fd-history-info">Undo: 0</span>
</div>`;

    return $(html);
  }

  /* ── Lifecycle ── */

  activateListeners(html) {
    super.activateListeners(html);

    this._wrap = document.getElementById("fd-canvas-wrap");
    this._svg  = document.getElementById("foundrydraw-svg");

    if (!this._wrap || !this._svg) {
      console.error(`${MODULE_ID} | SVG element not found in DOM`);
      return;
    }

    // Build SVG structure (defs, background layers, content/preview groups)
    this._buildSvgStructure();

    this._initWhenReady(0);
    this._bindControls(html);
    this._bindSvgEvents();

    this._resizeObserver = new ResizeObserver(() => this._onResize());
    this._resizeObserver.observe(this._wrap);

    this._keyHandler = (e) => {
      if (!this.rendered) return;
      const focused = document.activeElement;
      if (focused && (
        focused.tagName === "INPUT" ||
        focused.tagName === "TEXTAREA" ||
        focused.isContentEditable
      )) return;
      if (e.key === "Escape") {
        if (this._insertCircleMode) { this._exitCircleMode(); }
        return;
      }
      const isZ = e.key === "z" || e.key === "Z";
      if (e.ctrlKey && isZ && !e.shiftKey) { e.preventDefault(); e.stopPropagation(); this._undo(); return; }
      if (e.ctrlKey && isZ &&  e.shiftKey) { e.preventDefault(); e.stopPropagation(); this._redo(); return; }
      if (e.ctrlKey && e.key === "y")       { e.preventDefault(); e.stopPropagation(); this._redo(); return; }
    };
    document.addEventListener("keydown", this._keyHandler, true);
  }

  setPosition(pos = {}) {
    const result = super.setPosition(pos);
    requestAnimationFrame(() => this._onResize());
    return result;
  }

  async close(options = {}) {
    if (this._resizeObserver) this._resizeObserver.disconnect();
    if (this._keyHandler) document.removeEventListener("keydown", this._keyHandler, true);
    return super.close(options);
  }

  /* ──────────────────────────────────────────────
     SVG helpers
     ────────────────────────────────────────────── */

  /** Create an SVG-namespaced element with a map of attributes. */
  _svgEl(tag, attrs = {}) {
    const el = document.createElementNS(SVG_NS, tag);
    for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
    return el;
  }

  /**
   * Populate the initially-empty <svg> element with the permanent structure:
   *   <defs>  vignette gradient + grid pattern
   *   <rect>  parchment background
   *   <rect>  vignette overlay
   *   <rect>  grid overlay
   *   <g id="fd-content">   drawing elements (subject to undo/redo)
   *   <g id="fd-preview">   live shape preview while dragging (never in history)
   *
   * Called once in activateListeners(); also safe to call again after re-render.
   */
  _buildSvgStructure() {
    // Clear any previous content (safe for re-render)
    while (this._svg.firstChild) this._svg.removeChild(this._svg.firstChild);

    /* ── defs ── */
    const defs = this._svgEl("defs");

    // Radial vignette gradient (matches the old canvas vignette: transparent centre,
    // slightly darkened edges).  r = 80% of world size ≈ inner-radius / outer-radius ratio.
    const grad = this._svgEl("radialGradient", {
      id:             "fd-vignette",
      gradientUnits:  "userSpaceOnUse",
      cx: WORLD_SIZE / 2,  cy: WORLD_SIZE / 2,
      r:  WORLD_SIZE * 0.8,
      fx: WORLD_SIZE / 2,  fy: WORLD_SIZE / 2,
    });
    grad.appendChild(this._svgEl("stop", { offset: "0%",   "stop-color": "rgba(0,0,0,0)" }));
    grad.appendChild(this._svgEl("stop", { offset: "31%",  "stop-color": "rgba(0,0,0,0)" }));
    grad.appendChild(this._svgEl("stop", { offset: "100%", "stop-color": "rgba(60,30,0,0.2)" }));

    // 20×20 world-unit reference grid.
    // vector-effect="non-scaling-stroke" keeps lines hairline-thin at every zoom level.
    const pat = this._svgEl("pattern", {
      id:            "fd-grid-pat",
      x: 0,  y: 0,
      width:  20,  height: 20,
      patternUnits: "userSpaceOnUse",
    });
    pat.appendChild(this._svgEl("path", {
      d:                 "M 20 0 L 0 0 0 20",
      fill:              "none",
      stroke:            "rgba(160,110,30,0.8)",
      "stroke-width":    "0.5",
      "vector-effect":   "non-scaling-stroke",
    }));

    defs.appendChild(grad);
    defs.appendChild(pat);
    this._svg.appendChild(defs);

    /* ── permanent background layers (never cleared) ── */
    this._svg.appendChild(this._svgEl("rect", {
      x: 0,  y: 0,  width: WORLD_SIZE,  height: WORLD_SIZE,
      fill: PARCHMENT,
    }));
    this._svg.appendChild(this._svgEl("rect", {
      x: 0,  y: 0,  width: WORLD_SIZE,  height: WORLD_SIZE,
      fill: "url(#fd-vignette)",
      "pointer-events": "none",
    }));
    this._svg.appendChild(this._svgEl("rect", {
      id:               "fd-grid-overlay",
      x: 0,  y: 0,  width: WORLD_SIZE,  height: WORLD_SIZE,
      fill:             "url(#fd-grid-pat)",
      "pointer-events": "none",
    }));

    /* ── drawing content (undo/redo operates on this group) ── */
    this._contentGroup = this._svgEl("g", {
      id:               "fd-content",
      "pointer-events": "none",
    });
    this._svg.appendChild(this._contentGroup);

    /* ── shape preview during drag (temporary, never saved to history) ── */
    this._previewGroup = this._svgEl("g", {
      id:               "fd-preview",
      "pointer-events": "none",
    });
    this._svg.appendChild(this._previewGroup);
  }

  /* ──────────────────────────────────────────────
     Initialisation  (waits for layout to settle)
     ────────────────────────────────────────────── */

  _initWhenReady(attempts) {
    if (!this._wrap) return;
    const w = this._wrap.clientWidth;
    const h = this._wrap.clientHeight;
    if (w <= 0 || h <= 0) {
      if (attempts < 20) setTimeout(() => this._initWhenReady(attempts + 1), 16);
      return;
    }
    this._svg.setAttribute("width",  w);
    this._svg.setAttribute("height", h);
    this._initCanvas();
  }

  /** Window was resized – update SVG pixel dimensions and re-render the viewport.
      The drawing content (SVG elements) is untouched. */
  _onResize() {
    if (!this._svg || !this._wrap) return;
    const w = this._wrap.clientWidth;
    const h = this._wrap.clientHeight;
    if (w <= 0 || h <= 0) return;
    this._svg.setAttribute("width",  w);
    this._svg.setAttribute("height", h);
    this._renderViewport();
  }

  _initCanvas() {
    this._contentGroup.innerHTML = "";
    this._activePaths = [];
    this._pathDataArr = [];
    this._history     = [];
    this._redoStack        = [];
    this._centerView();
    this._saveHistory();
    this._renderViewport();
    this._updateHistoryInfo();
  }

  /* ──────────────────────────────────────────────
     Viewport  (pan / zoom via SVG viewBox)
     ────────────────────────────────────────────── */

  /** Centre the viewport on the world centre at the current zoom level. */
  _centerView() {
    const w = this._wrap?.clientWidth  ?? 820;
    const h = this._wrap?.clientHeight ?? 600;
    this._viewX = (WORLD_SIZE - w / this._zoom) / 2;
    this._viewY = (WORLD_SIZE - h / this._zoom) / 2;
  }

  /**
   * Update the SVG viewBox to reflect the current pan / zoom state.
   * This is the entire "render" step – no pixel blit needed.
   */
  _renderViewport() {
    if (!this._svg || !this._wrap) return;
    const w  = this._wrap.clientWidth;
    const h  = this._wrap.clientHeight;
    if (!w || !h) return;
    this._svg.setAttribute(
      "viewBox",
      `${this._viewX} ${this._viewY} ${w / this._zoom} ${h / this._zoom}`
    );
    this._updateCenterMarker();
    this._updateZoomInfo();
  }

  /** Keep the CSS crosshair div centred over the symmetry point. */
  _updateCenterMarker() {
    const marker = document.getElementById("fd-center-marker");
    if (!marker) return;
    const scx = Math.round((WORLD_SIZE / 2 - this._viewX) * this._zoom);
    const scy = Math.round((WORLD_SIZE / 2 - this._viewY) * this._zoom);
    marker.style.left = scx + "px";
    marker.style.top  = scy + "px";
  }

  _updateZoomInfo() {
    const el = document.getElementById("fd-zoom-info");
    if (el) el.textContent = `${Math.round(this._zoom * 100)}%`;
  }

  /** Clear all drawing content (background rects are permanent and unaffected). */
  _fillBackground() {
    if (this._contentGroup) this._contentGroup.innerHTML = "";
    // Abort any in-progress stroke
    this._activePaths = [];
    this._pathDataArr = [];
    this._drawing     = false;
  }

  /* ──────────────────────────────────────────────
     Coordinate transform
     ────────────────────────────────────────────── */

  /** Convert a point in SVG pixel space to world coordinates. */
  _screenToWorld(sx, sy) {
    return {
      x: this._viewX + sx / this._zoom,
      y: this._viewY + sy / this._zoom,
    };
  }

  /* ──────────────────────────────────────────────
     Control Bindings
     ────────────────────────────────────────────── */

  _bindControls(html) {
    html.find(".fd-tool-btn[data-tool]").on("click", (e) => {
      this._exitCircleMode();
      const btn = e.currentTarget;
      html.find(".fd-tool-btn[data-tool]").removeClass("active");
      btn.classList.add("active");
      this._tool = btn.dataset.tool;
      this._wrap.className = `foundrydraw-canvas-wrap tool-${this._tool}`;
    });

    html.find("#fd-color-picker").on("input", (e) => {
      this._color = e.currentTarget.value;
    });

    html.find("#fd-brush-size").on("input", (e) => {
      this._brushSize = parseInt(e.currentTarget.value);
      html.find("#fd-brush-size-val").text(this._brushSize);
    });

    html.find("#fd-smooth").on("input", (e) => {
      this._smoothness = parseInt(e.currentTarget.value);
      html.find("#fd-smooth-val").text(this._smoothness);
    });

    html.find("#fd-symmetry").on("change", (e) => {
      this._symmetry = parseInt(e.currentTarget.value);
    });

    html.find("#fd-undo").on("click", () => this._undo());
    html.find("#fd-redo").on("click", () => this._redo());
    html.find("#fd-insert-circle").on("click", () => {
      if (this._insertCircleMode) this._exitCircleMode();
      else this._enterCircleMode();
    });

    html.find("#fd-center-view").on("click", () => {
      this._zoom = 1.0;
      this._centerView();
      this._renderViewport();
    });

    html.find("#fd-clear").on("click", () => {
      this._redoStack = [];
      this._exitCircleMode();
      this._fillBackground();
      this._saveHistory();
      this._updateHistoryInfo();
    });

    html.find("#fd-clipboard").on("click",    () => this._copyToClipboard());
    html.find("#fd-save-gallery").on("click", () => this._saveToGallery());
    html.find("#fd-save").on("click",         () => this._saveImage());
    if (game.user.isGM) {
      html.find("#fd-show-players").on("click", () => this._showToPlayers());
    }
  }

  /* ──────────────────────────────────────────────
     SVG Event Handling
     ────────────────────────────────────────────── */

  _bindSvgEvents() {
    const el = this._svg;
    el.addEventListener("contextmenu",   (e) => e.preventDefault());
    el.addEventListener("pointerdown",   (e) => this._onPointerDown(e));
    el.addEventListener("pointermove",   (e) => this._onPointerMove(e));
    el.addEventListener("pointerup",     (e) => this._onPointerUp(e));
    el.addEventListener("pointercancel", ()  => {
      this._drawing     = false;
      this._panning     = false;
      this._activePaths = [];
      this._pathDataArr = [];
      this._wrap.classList.remove("fd-panning");
    });
    el.addEventListener("pointerleave",  (e) => {
      if (this._drawing) this._onPointerUp(e);
      if (this._panning) {
        this._panning = false;
        this._wrap.classList.remove("fd-panning");
      }
    });
    el.addEventListener("mousemove",     (e) => {
      this._updateCoords(e);
      if (this._insertCircleMode) this._updateCirclePreview(e);
    });
    el.addEventListener("wheel",         (e) => this._onWheel(e), { passive: false });
  }

  /** Returns the pointer position in SVG pixel space (== screen coords relative to SVG). */
  _canvasPoint(e) {
    const rect = this._svg.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  }

  _updateCoords(e) {
    const sp = this._canvasPoint(e);
    const wp = this._screenToWorld(sp.x, sp.y);
    const el = document.getElementById("fd-coords");
    // Show coords relative to the symmetry centre (world centre = 0,0)
    if (el) el.textContent =
      `x: ${Math.round(wp.x - WORLD_SIZE / 2)}  y: ${Math.round(wp.y - WORLD_SIZE / 2)}`;
  }

  /* ── Zoom ── */

  _onWheel(e) {
    e.preventDefault();
    const factor  = e.deltaY < 0 ? ZOOM_FACTOR : 1 / ZOOM_FACTOR;
    const newZoom = Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, this._zoom * factor));
    if (newZoom === this._zoom) return;

    // Keep the world-point under the cursor fixed on screen
    const sp     = this._canvasPoint(e);
    this._viewX += sp.x / this._zoom - sp.x / newZoom;
    this._viewY += sp.y / this._zoom - sp.y / newZoom;
    this._zoom   = newZoom;
    this._renderViewport();
  }

  /* ── Pointer events ── */

  _onPointerDown(e) {
    e.preventDefault();

    // ── Insert-circle mode ──────────────────────────────────────────────────
    // Left-click places the circle at the hovered radius; anything else cancels.
    if (this._insertCircleMode) {
      if (e.button === 0) {
        const sp = this._canvasPoint(e);
        const wp = this._screenToWorld(sp.x, sp.y);
        const cx = WORLD_SIZE / 2;
        const cy = WORLD_SIZE / 2;
        const r  = Math.hypot(wp.x - cx, wp.y - cy);
        if (r >= 1) {
          this._redoStack = [];
          this._contentGroup.appendChild(this._svgEl("circle", {
            cx:               cx.toFixed(2),
            cy:               cy.toFixed(2),
            r:                r.toFixed(2),
            stroke:           this._color,
            "stroke-width":   this._brushSize,
            "stroke-linecap": "round",
            fill:             "none",
            opacity:          this._opacity,
          }));
          this._saveHistory();
          this._updateHistoryInfo();
        }
      }
      this._exitCircleMode();
      return;
    }

    if (e.button === 2) {
      // Right-click → pan
      this._panning  = true;
      this._panLastX = e.clientX;
      this._panLastY = e.clientY;
      this._svg.setPointerCapture(e.pointerId);
      this._wrap.classList.add("fd-panning");
      return;
    }
    if (e.button !== 0) return;

    this._svg.setPointerCapture(e.pointerId);
    this._drawing = true;
    const sp = this._canvasPoint(e);
    const wp = this._screenToWorld(sp.x, sp.y);
    // Alt: snap the start point to the grid for shape tools so the whole shape
    // is grid-aligned from the very first point.
    if (e.altKey && ["line", "circle", "rect"].includes(this._tool)) {
      const sg = this._snapToGrid(wp.x, wp.y);
      this._startX = this._lastX = sg.x;
      this._startY = this._lastY = sg.y;
    } else {
      this._startX = this._lastX = wp.x;
      this._startY = this._lastY = wp.y;
    }
    // Initialise the EMA stabiliser at the exact cursor so the first
    // segment starts cleanly regardless of the smoothness setting.
    this._smoothX = wp.x;
    this._smoothY = wp.y;
    this._redoStack = [];

    if (this._tool === "brush" || this._tool === "eraser") {
      const isEraser = this._tool === "eraser";
      this._activePaths = [];
      this._pathDataArr = [];

      // Create one <path> element per symmetry axis and put it in the content group.
      // "M x y L x y" is a zero-length line; with stroke-linecap="round" it renders
      // as a solid dot — so a simple click (no drag) always leaves a visible mark.
      this._withSymmetry(wp.x, wp.y, (cx, cy, tx, ty) => {
        const d = `M ${tx.toFixed(2)} ${ty.toFixed(2)} L ${tx.toFixed(2)} ${ty.toFixed(2)}`;
        const pathEl = this._svgEl("path", {
          stroke:            isEraser ? PARCHMENT : this._color,
          "stroke-width":    this._brushSize,
          "stroke-linecap":  "round",
          "stroke-linejoin": "round",
          fill:              "none",
          opacity:           this._opacity,
          d,
        });
        this._contentGroup.appendChild(pathEl);
        this._activePaths.push(pathEl);
        this._pathDataArr.push(d);
      });
    }
  }

  _onPointerMove(e) {
    if (this._panning) {
      const dx      = (e.clientX - this._panLastX) / this._zoom;
      const dy      = (e.clientY - this._panLastY) / this._zoom;
      this._viewX  -= dx;
      this._viewY  -= dy;
      this._panLastX = e.clientX;
      this._panLastY = e.clientY;
      this._renderViewport();
      return;
    }
    if (!this._drawing) return;

    const sp = this._canvasPoint(e);
    const wp = this._screenToWorld(sp.x, sp.y);

    if (this._tool === "brush" || this._tool === "eraser") {
      // EMA stabiliser: alpha=1 → exact cursor; alpha→0 → heavy smoothing
      const alpha    = this._smoothness === 0 ? 1.0 : 1.0 - this._smoothness * 0.09;
      this._smoothX += (wp.x - this._smoothX) * alpha;
      this._smoothY += (wp.y - this._smoothY) * alpha;
      this._extendStroke(this._smoothX, this._smoothY);
      this._lastX = this._smoothX;
      this._lastY = this._smoothY;
      // SVG automatically re-renders when an attribute changes — no explicit redraw.
    } else {
      // Shape tools: update the live preview group
      const ep = this._constrainEndpoint(this._startX, this._startY, wp.x, wp.y, e.shiftKey, e.ctrlKey, e.altKey);
      this._previewGroup.innerHTML = "";
      this._drawShapeToGroup(this._previewGroup, this._startX, this._startY, ep.x2, ep.y2);
    }
  }

  _onPointerUp(e) {
    if (this._panning) {
      this._panning = false;
      this._wrap.classList.remove("fd-panning");
      return;
    }
    if (!this._drawing) return;
    this._drawing = false;

    const sp = this._canvasPoint(e);
    const wp = this._screenToWorld(sp.x, sp.y);

    if (["line", "circle", "rect"].includes(this._tool)) {
      const ep = this._constrainEndpoint(this._startX, this._startY, wp.x, wp.y, e.shiftKey, e.ctrlKey, e.altKey);
      this._previewGroup.innerHTML = "";
      this._drawShapeToGroup(this._contentGroup, this._startX, this._startY, ep.x2, ep.y2);
    } else if ((this._tool === "brush" || this._tool === "eraser") && this._smoothness > 0) {
      // Flush remaining stabiliser lag so the stroke always ends at the exact cursor.
      if (this._lastX !== wp.x || this._lastY !== wp.y) {
        this._extendStroke(wp.x, wp.y);
      }
    }

    this._activePaths = [];
    this._pathDataArr = [];
    this._saveHistory();
    this._updateHistoryInfo();
  }

  /* ──────────────────────────────────────────────
     Drawing — brush / eraser
     ────────────────────────────────────────────── */

  /**
   * Append a L(ine-to) command to every active path element, extending the
   * stroke to the given world-coordinate point (and its symmetry copies).
   */
  _extendStroke(x2, y2) {
    if (!this._activePaths.length) return;
    let i = 0;
    this._withSymmetry(x2, y2, (cx, cy, tx, ty) => {
      if (!this._activePaths[i]) { i++; return; }
      this._pathDataArr[i] += ` L ${tx.toFixed(2)} ${ty.toFixed(2)}`;
      this._activePaths[i].setAttribute("d", this._pathDataArr[i]);
      i++;
    });
  }

  /* ──────────────────────────────────────────────
     Drawing — shapes
     ────────────────────────────────────────────── */

  /** Snap a world coordinate to the nearest 20-unit grid point. */
  _snapToGrid(x, y) {
    const g = 20;
    return { x: Math.round(x / g) * g, y: Math.round(y / g) * g };
  }

  /**
   * Apply modifier-key constraints to a shape endpoint before drawing.
   *
   * Alt   — snap the endpoint to the nearest 20-unit grid point (same grid
   *         shown on screen).  Works for all shape tools.
   * Ctrl  — snap the direction from (x1,y1) to (x2,y2) to the nearest 45°
   *         increment (0°, 45°, 90°, 135°, …).  Works for all shape tools.
   * Shift — lock to equal dimensions so rect → square, ellipse → circle.
   *         Applies to "circle" and "rect" only; ignored for "line".
   *
   * Constraints are applied in order: Alt first (grid snap), Ctrl next
   * (direction snap), then Shift (equalise magnitudes).
   */
  _constrainEndpoint(x1, y1, x2, y2, shift, ctrl, alt) {
    let ex = x2, ey = y2;

    if (alt) {
      const sg = this._snapToGrid(ex, ey);
      ex = sg.x;
      ey = sg.y;
    }

    let dx = ex - x1, dy = ey - y1;

    if (ctrl) {
      const r = Math.hypot(dx, dy);
      if (r > 0) {
        const snapped = Math.round(Math.atan2(dy, dx) / (Math.PI / 4)) * (Math.PI / 4);
        dx = r * Math.cos(snapped);
        dy = r * Math.sin(snapped);
      }
    }

    if (shift && (this._tool === "circle" || this._tool === "rect")) {
      const s = Math.min(Math.abs(dx), Math.abs(dy));
      dx = (dx >= 0 ? 1 : -1) * s;
      dy = (dy >= 0 ? 1 : -1) * s;
    }

    return { x2: x1 + dx, y2: y1 + dy };
  }

  /**
   * Create SVG shape elements for the current tool (line / circle / rect) and
   * append them to `group`.  Respects symmetry — creates one element per axis.
   *
   * Symmetry is applied by building the i=0 shape in world coordinates and then
   * rotating the whole element around the world centre for each subsequent copy.
   * This is correct for all tools:
   *   • line   — rotating two endpoints is equivalent to rotating the whole line ✓
   *   • ellipse — rotates the shape intact; the old approach of rotating the two
   *               bounding-box corners and recomputing rx/ry gave wrong sizes
   *               at non-axis-aligned angles (visible as distortion at 6/8/12-fold)
   *   • rect   — same issue; a `transform="rotate(…)"` rect renders correctly as
   *               a rotated rectangle rather than a mis-sized axis-aligned one
   */
  _drawShapeToGroup(group, x1, y1, x2, y2) {
    const wcx  = WORLD_SIZE / 2;
    const wcy  = WORLD_SIZE / 2;
    const step = (Math.PI * 2) / this._symmetry;

    const base = {
      stroke:            this._color,
      "stroke-width":    this._brushSize,
      "stroke-linecap":  "round",
      "stroke-linejoin": "round",
      fill:              "none",
      opacity:           this._opacity,
    };

    // Build the prototype element (i = 0, no rotation).
    let proto;
    if (this._tool === "line") {
      proto = this._svgEl("line", {
        ...base,
        x1: x1.toFixed(2),  y1: y1.toFixed(2),
        x2: x2.toFixed(2),  y2: y2.toFixed(2),
      });
    } else if (this._tool === "circle") {
      const rx = Math.abs(x2 - x1) / 2;
      const ry = Math.abs(y2 - y1) / 2;
      proto = this._svgEl("ellipse", {
        ...base,
        cx: ((x1 + x2) / 2).toFixed(2),
        cy: ((y1 + y2) / 2).toFixed(2),
        rx: (rx || 1).toFixed(2),
        ry: (ry || 1).toFixed(2),
      });
    } else if (this._tool === "rect") {
      proto = this._svgEl("rect", {
        ...base,
        x:      Math.min(x1, x2).toFixed(2),
        y:      Math.min(y1, y2).toFixed(2),
        width:  Math.abs(x2 - x1).toFixed(2),
        height: Math.abs(y2 - y1).toFixed(2),
      });
    }
    if (!proto) return;

    // Stamp one copy per symmetry axis, rotating around the world centre.
    for (let i = 0; i < this._symmetry; i++) {
      const copy = i === 0 ? proto : proto.cloneNode(false);
      if (i > 0) {
        const deg = (step * i * 180 / Math.PI).toFixed(4);
        copy.setAttribute("transform", `rotate(${deg} ${wcx} ${wcy})`);
      }
      group.appendChild(copy);
    }
  }

  /* ──────────────────────────────────────────────
     Insert-circle mode
     Press the button → cursor becomes a radius picker; hover shows a live
     preview circle centred on the world centre; click to place it.
     ────────────────────────────────────────────── */

  _enterCircleMode() {
    this._insertCircleMode = true;
    this._previewGroup.innerHTML = "";
    this._wrap.classList.add("fd-insert-circle-mode");
    document.getElementById("fd-insert-circle")?.classList.add("active");
  }

  _exitCircleMode() {
    if (!this._insertCircleMode) return;
    this._insertCircleMode = false;
    this._previewGroup.innerHTML = "";
    this._wrap.classList.remove("fd-insert-circle-mode");
    document.getElementById("fd-insert-circle")?.classList.remove("active");
  }

  /** Redraw the preview circle in `_previewGroup` based on cursor distance from world centre. */
  _updateCirclePreview(e) {
    const sp = this._canvasPoint(e);
    const wp = this._screenToWorld(sp.x, sp.y);
    const cx = WORLD_SIZE / 2;
    const cy = WORLD_SIZE / 2;
    const r  = Math.hypot(wp.x - cx, wp.y - cy);

    this._previewGroup.innerHTML = "";
    if (r < 1) return;

    this._previewGroup.appendChild(this._svgEl("circle", {
      cx:               cx.toFixed(2),
      cy:               cy.toFixed(2),
      r:                r.toFixed(2),
      stroke:           this._color,
      "stroke-width":   this._brushSize,
      "stroke-linecap": "round",
      fill:             "none",
      opacity:          this._opacity,
    }));
  }

  /* ──────────────────────────────────────────────
     Symmetry
     ────────────────────────────────────────────── */

  /**
   * Call fn(cx, cy, tx, ty, i) for each symmetry copy of (x, y).
   * i = 0 is the original position; i = 1..N-1 are rotated copies.
   * The symmetry centre is always the world centre — it never drifts.
   */
  _withSymmetry(x, y, fn) {
    const cx        = WORLD_SIZE / 2;
    const cy        = WORLD_SIZE / 2;
    const dx        = x - cx,  dy = y - cy;
    const baseAngle = Math.atan2(dy, dx);
    const r         = Math.hypot(dx, dy);
    const step      = (Math.PI * 2) / this._symmetry;
    for (let i = 0; i < this._symmetry; i++) {
      const angle = baseAngle + step * i;
      fn(cx, cy, cx + r * Math.cos(angle), cy + r * Math.sin(angle), i);
    }
  }

  /* ──────────────────────────────────────────────
     History (Undo / Redo)
     ────────────────────────────────────────────── */

  /**
   * Snapshot the current drawing content.
   * Each snapshot is an array of cloned SVG nodes — far smaller than the
   * 16 MB ImageData snapshots used by the old canvas approach.
   */
  _saveHistory() {
    if (!this._contentGroup) return;
    const snap = Array.from(this._contentGroup.children).map(n => n.cloneNode(true));
    this._history.push(snap);
    if (this._history.length > MAX_HISTORY) this._history.shift();
    this._updateHistoryInfo();
  }

  _restoreSnapshot(snap) {
    this._contentGroup.innerHTML = "";
    for (const node of snap) this._contentGroup.appendChild(node.cloneNode(true));
  }

  _undo() {
    if (this._history.length <= 1) return;
    this._redoStack.push(this._history.pop());
    this._restoreSnapshot(this._history[this._history.length - 1]);
    this._updateHistoryInfo();
  }

  _redo() {
    if (!this._redoStack.length) return;
    const snap = this._redoStack.pop();
    this._history.push(snap);
    this._restoreSnapshot(snap);
    this._updateHistoryInfo();
  }

  _updateHistoryInfo() {
    const el = document.getElementById("fd-history-info");
    if (el) el.textContent = `Undo: ${this._history.length - 1}  Redo: ${this._redoStack.length}`;
  }

  /* ──────────────────────────────────────────────
     Export
     ────────────────────────────────────────────── */

  /**
   * Return a deep clone of the SVG prepared for export:
   *  - viewBox covers the full 2000×2000 world
   *  - preview group is empty
   *  - grid overlay is removed (it is an editing aid, not part of the drawing)
   */
  _cloneForExport(width = WORLD_SIZE, height = WORLD_SIZE) {
    this._previewGroup.innerHTML = "";
    const clone = this._svg.cloneNode(true);
    clone.setAttribute("viewBox", `0 0 ${WORLD_SIZE} ${WORLD_SIZE}`);
    clone.setAttribute("width",   width);
    clone.setAttribute("height",  height);
    clone.querySelector("#fd-grid-overlay")?.remove();
    return clone;
  }

  /**
   * Render the full 2000×2000 world to an offscreen <canvas> and return it.
   * We clone the SVG instead of mutating the live element to avoid a visual flash.
   */
  async _rasterize(width = WORLD_SIZE, height = WORLD_SIZE) {
    const clone  = this._cloneForExport(width, height);
    const svgStr = new XMLSerializer().serializeToString(clone);

    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width  = width;
        canvas.height = height;
        canvas.getContext("2d").drawImage(img, 0, 0, width, height);
        resolve(canvas);
      };
      img.onerror = reject;
      img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svgStr);
    });
  }

  async _copyToClipboard() {
    let canvas;
    try {
      canvas = await this._rasterize();
    } catch (err) {
      console.warn(`${MODULE_ID} | rasterize for clipboard failed:`, err);
      ui.notifications.warn("FoundryDraw: could not rasterise SVG for clipboard.");
      return;
    }

    const hasClipboard = typeof navigator !== "undefined" &&
                         navigator.clipboard &&
                         typeof ClipboardItem !== "undefined" &&
                         window.isSecureContext;
    if (hasClipboard) {
      try {
        const blob = await new Promise(resolve => canvas.toBlob(resolve, "image/png"));
        await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
        ui.notifications.info(game.i18n.localize("FOUNDRYDRAW.Actions.CopiedClipboard"));
        return;
      } catch (err) {
        console.warn(`${MODULE_ID} | clipboard write failed, falling back:`, err);
      }
    }

    const dataUrl = canvas.toDataURL("image/png");
    const win = window.open();
    if (win) {
      win.document.write(
        `<img src="${dataUrl}" style="max-width:100%;background:#888"
              title="Rechtsklick → Bild kopieren / Right-click → Copy Image">`
      );
      ui.notifications.info(game.i18n.localize("FOUNDRYDRAW.Actions.CopyFallback"));
    } else {
      ui.notifications.warn(game.i18n.localize("FOUNDRYDRAW.Actions.CopyFailed"));
    }
  }

  async _showToPlayers() {
    if (!game.user.isGM) return;
    let canvas;
    try {
      canvas = await this._rasterize();
    } catch (err) {
      console.warn(`${MODULE_ID} | rasterize for players failed:`, err);
      ui.notifications.warn("FoundryDraw: could not prepare image for players.");
      return;
    }
    const src   = canvas.toDataURL("image/png");
    const title = game.i18n.localize("FOUNDRYDRAW.WindowTitle");
    new ImagePopout(src, { window: { title }, shareable: false }).render(true);
    game.socket.emit(`module.${MODULE_ID}`, { type: "showImage", src, title });
  }

  /** Download the drawing as a true .svg file (infinite resolution). */
  _saveImage() {
    const clone  = this._cloneForExport();
    const svgStr = new XMLSerializer().serializeToString(clone);
    const blob   = new Blob([svgStr], { type: "image/svg+xml;charset=utf-8" });
    const link   = document.createElement("a");
    link.download = `magic-circle-${Date.now()}.svg`;
    link.href     = URL.createObjectURL(blob);
    link.click();
    URL.revokeObjectURL(link.href);
  }

  async _saveToGallery() {
    const name = await _promptName(
      game.i18n.localize("FOUNDRYDRAW.Gallery.NameTitle"), ""
    );
    if (name === null) return;
    const trimmed = name.trim() || game.i18n.localize("FOUNDRYDRAW.Gallery.Unnamed");

    // Store the raw SVG content HTML for lossless editing (no re-encoding round-trip).
    const contentHtml = this._contentGroup.innerHTML;

    // Build a full-world SVG data URL for the gallery thumbnail (grid excluded).
    const clone   = this._cloneForExport();
    const svgStr  = new XMLSerializer().serializeToString(clone);
    const dataUrl = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svgStr);

    const gallery = game.settings.get(MODULE_ID, "gallery");
    gallery.push({
      id:          foundry.utils.randomID(),
      name:        trimmed,
      dataUrl,      // SVG data URL used as <img src=…> in gallery thumbnails
      contentHtml,  // raw SVG group content for lossless reload into the editor
      createdAt:   Date.now(),
    });
    await game.settings.set(MODULE_ID, "gallery", gallery);
    ui.notifications.info(game.i18n.localize("FOUNDRYDRAW.Gallery.Saved"));
    if (_galleryInstance?.rendered) _galleryInstance.render();
  }

  /**
   * Load a gallery entry back into the draw pad.
   *
   * @param {string}  dataUrl     - SVG or PNG data URL (thumbnail; also used for PNG fallback)
   * @param {string}  [contentHtml] - SVG content group HTML string (modern SVG entries)
   */
  _loadFromDataUrl(dataUrl, contentHtml) {
    return new Promise((resolve) => {
      // Abort any in-progress stroke
      this._activePaths = [];
      this._pathDataArr = [];

      if (contentHtml !== undefined && contentHtml !== null) {
        // Modern SVG entry: restore content directly — lossless, instant.
        this._contentGroup.innerHTML = contentHtml;
        this._finishLoad(resolve);
      } else {
        // Legacy PNG entry (pre-v1.6): embed as an SVG <image> element.
        const img = new Image();
        img.onload = () => {
          this._contentGroup.innerHTML = "";
          const scale   = Math.min(WORLD_SIZE / img.width, WORLD_SIZE / img.height);
          const dw      = Math.round(img.width  * scale);
          const dh      = Math.round(img.height * scale);
          const imageEl = this._svgEl("image", {
            x:      (WORLD_SIZE - dw) / 2,
            y:      (WORLD_SIZE - dh) / 2,
            width:  dw,
            height: dh,
            href:   dataUrl,
          });
          this._contentGroup.appendChild(imageEl);
          this._finishLoad(resolve);
        };
        img.onerror = () => this._finishLoad(resolve);
        img.src = dataUrl;
      }
    });
  }

  _finishLoad(resolve) {
    this._exitCircleMode();
    this._zoom      = 1.0;
    this._centerView();
    this._redoStack = [];
    this._history          = [];
    this._saveHistory();
    this._renderViewport();
    this._updateHistoryInfo();
    resolve();
  }
}

/* ──────────────────────────────────────────────
   Shared helper – name prompt dialog
   ────────────────────────────────────────────── */

function _promptName(title, defaultValue = "") {
  return new Promise((resolve) => {
    new Dialog({
      title,
      content: `<div style="margin-bottom:8px">
        <input type="text" id="fd-gallery-name" value="${defaultValue}"
               style="width:100%;box-sizing:border-box">
      </div>`,
      buttons: {
        ok: {
          icon:     '<i class="fas fa-check"></i>',
          label:    game.i18n.localize("FOUNDRYDRAW.Gallery.Confirm"),
          callback: (html) => resolve(html.find("#fd-gallery-name").val()),
        },
        cancel: {
          icon:     '<i class="fas fa-times"></i>',
          label:    game.i18n.localize("Cancel"),
          callback: () => resolve(null),
        },
      },
      default: "ok",
      render:  (html) => {
        const inp = html.find("#fd-gallery-name")[0];
        if (inp) { inp.focus(); inp.select(); }
      },
    }).render(true);
  });
}

/* ──────────────────────────────────────────────
   Gallery Application
   ────────────────────────────────────────────── */

class FoundryDrawGallery extends Application {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id:          "foundrydraw-gallery",
      title:       game.i18n.localize("FOUNDRYDRAW.GalleryTitle"),
      template:    null,
      classes:     ["foundrydraw-gallery"],
      width:       580,
      height:      480,
      resizable:   true,
      minimizable: true,
    });
  }

  async _renderInner() {
    const i18n   = (k) => game.i18n.localize(`FOUNDRYDRAW.${k}`);
    const gallery = game.settings.get(MODULE_ID, "gallery");

    let items = "";
    if (gallery.length === 0) {
      items = `<p class="fd-gallery-empty">${i18n("Gallery.Empty")}</p>`;
    } else {
      for (const entry of gallery) {
        const gmBtn = game.user.isGM
          ? `<button class="fd-gallery-btn fd-gallery-show" data-id="${entry.id}"
                     title="${i18n("Gallery.Show")}"><i class="fas fa-eye"></i></button>`
          : "";
        items += `
          <div class="fd-gallery-item" data-id="${entry.id}">
            <img class="fd-gallery-thumb" src="${entry.dataUrl}" alt="${entry.name}">
            <div class="fd-gallery-name">${entry.name}</div>
            <div class="fd-gallery-actions">
              <button class="fd-gallery-btn fd-gallery-edit" data-id="${entry.id}"
                      title="${i18n("Gallery.Edit")}"><i class="fas fa-pencil-alt"></i></button>
              <button class="fd-gallery-btn fd-gallery-rename" data-id="${entry.id}"
                      title="${i18n("Gallery.Rename")}"><i class="fas fa-i-cursor"></i></button>
              ${gmBtn}
              <button class="fd-gallery-btn fd-gallery-delete" data-id="${entry.id}"
                      title="${i18n("Gallery.Delete")}"><i class="fas fa-trash"></i></button>
            </div>
          </div>`;
      }
    }

    return $(`<div class="fd-gallery-grid">${items}</div>`);
  }

  activateListeners(html) {
    super.activateListeners(html);
    html.find(".fd-gallery-edit").on("click",   (e) => this._editEntry(e.currentTarget.dataset.id));
    html.find(".fd-gallery-rename").on("click", (e) => this._renameEntry(e.currentTarget.dataset.id));
    html.find(".fd-gallery-show").on("click",   (e) => this._showEntry(e.currentTarget.dataset.id));
    html.find(".fd-gallery-delete").on("click", (e) => this._deleteEntry(e.currentTarget.dataset.id));
  }

  _editEntry(id) {
    const gallery = game.settings.get(MODULE_ID, "gallery");
    const entry   = gallery.find(e => e.id === id);
    if (!entry) return;
    openDrawApp();
    const tryLoad = (n) => {
      const app = _appInstance;
      if (app?._svg && app?._contentGroup) {
        // Pass contentHtml for SVG entries (lossless); undefined for legacy PNG entries.
        app._loadFromDataUrl(entry.dataUrl, entry.contentHtml);
      } else if (n < 40) {
        setTimeout(() => tryLoad(n + 1), 100);
      }
    };
    tryLoad(0);
  }

  async _renameEntry(id) {
    const gallery = game.settings.get(MODULE_ID, "gallery");
    const idx     = gallery.findIndex(e => e.id === id);
    if (idx < 0) return;
    const newName = await _promptName(
      game.i18n.localize("FOUNDRYDRAW.Gallery.RenameTitle"),
      gallery[idx].name
    );
    if (!newName?.trim()) return;
    gallery[idx].name = newName.trim();
    await game.settings.set(MODULE_ID, "gallery", gallery);
    this.render();
  }

  _showEntry(id) {
    if (!game.user.isGM) return;
    const gallery = game.settings.get(MODULE_ID, "gallery");
    const entry   = gallery.find(e => e.id === id);
    if (!entry) return;
    // SVG data URLs display correctly in ImagePopout's <img> element.
    new ImagePopout(entry.dataUrl, { window: { title: entry.name }, shareable: false }).render(true);
    game.socket.emit(`module.${MODULE_ID}`, { type: "showImage", src: entry.dataUrl, title: entry.name });
  }

  async _deleteEntry(id) {
    const gallery  = game.settings.get(MODULE_ID, "gallery");
    const filtered = gallery.filter(e => e.id !== id);
    await game.settings.set(MODULE_ID, "gallery", filtered);
    this.render();
  }
}

/* ──────────────────────────────────────────────
   Singleton + scene control buttons
   ────────────────────────────────────────────── */

let _appInstance     = null;
let _galleryInstance = null;

function openDrawApp() {
  if (!_appInstance || !_appInstance.rendered) {
    _appInstance = new FoundryDrawApp();
    _appInstance.render(true);
  } else {
    if (_appInstance._minimized) _appInstance.maximize();
    _appInstance.bringToTop();
  }
}

function openGallery() {
  if (!_galleryInstance || !_galleryInstance.rendered) {
    _galleryInstance = new FoundryDrawGallery();
    _galleryInstance.render(true);
  } else {
    if (_galleryInstance._minimized) _galleryInstance.maximize();
    _galleryInstance.bringToTop();
  }
}

/* ──────────────────────────────────────────────
   Socket – show image to all players
   ────────────────────────────────────────────── */

Hooks.once("ready", () => {
  game.socket.on(`module.${MODULE_ID}`, (data) => {
    if (data.type !== "showImage") return;
    new ImagePopout(data.src, {
      window:    { title: data.title ?? game.i18n.localize("FOUNDRYDRAW.WindowTitle") },
      shareable: false,
    }).render(true);
  });
});

Hooks.on("getSceneControlButtons", (controls) => {
  const group = controls.tokens ?? Object.values(controls)[0];
  if (!group?.tools) return;

  const baseOrder = (Object.keys(group.tools).length + 1) * 10;

  group.tools.foundrydraw = {
    name:     "foundrydraw",
    title:    game.i18n.localize("FOUNDRYDRAW.ButtonTitle"),
    icon:     "fas fa-magic",
    button:   true,
    visible:  true,
    order:    baseOrder,
    onChange: () => openDrawApp(),
  };

  group.tools.foundrydrawgallery = {
    name:     "foundrydrawgallery",
    title:    game.i18n.localize("FOUNDRYDRAW.GalleryTitle"),
    icon:     "fas fa-images",
    button:   true,
    visible:  true,
    order:    baseOrder + 10,
    onChange: () => openGallery(),
  };
});
